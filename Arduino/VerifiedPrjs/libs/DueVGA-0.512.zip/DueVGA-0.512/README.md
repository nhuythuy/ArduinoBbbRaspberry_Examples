DueVGA
======

Arduino Due VGA/PAL/NTSC library

See VGA/README.txt for instructions.

To install: move the VGA directory into your Arduino libraries directory, then (re)start the Arduino IDE.
