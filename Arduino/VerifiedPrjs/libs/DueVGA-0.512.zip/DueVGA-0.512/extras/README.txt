DueVGA Extras
=============

In this directory are some examples which are longer than the simple examples 
included in the library, or require special hardware or external circuitry or
extra libraries.


GPS
---
This sketch is best with a serial GPS adapter, but can be used via the serial
monitor. It decodes GPS strings and displays a globe and satellite positions.

SDCard
------
This directory contains instructions on how to use DueVGA in colour mode together
with the SdFat library. 